#include <graphics.h>
#include <iostream>
#include <conio.h>
#include <windows.h>
#include <stdio.h>

void boundary_fill(int, int, int, int );
//driver code
int main()
{
    // gm is Graphics mode which is
    // a computer display mode that
    // generates image using pixels.
    // DETECT is a macro defined in
    // "graphics.h" header file

    int gd = DETECT, gm;

    // initgraph initializes the
    // graphics system by loading a
    // graphics driver from disk
    initgraph(&gd, &gm,"");

    rectangle(50,50,250,250);

    boundary_fill(51,51,12,15);



    getch();

    // closegraph function closes the
    // graphics mode and deallocates
    // all memory allocated by
    // graphics system .
    closegraph();

    return 0;
}



void boundary_fill(int x, int y, int fill_color, int bounday_color)
{
    int c;
    c = getpixel (x, y);

    if (c!=fill_color && c!=bounday_color)
    {
        //SetPixel(x, y,fill_color);
        putpixel(x,y,fill_color);
        boundary_fill(x+1, y, fill_color, bounday_color);
        boundary_fill(x-1, y, fill_color, bounday_color);
        boundary_fill(x, y+1,fill_color, bounday_color);
        boundary_fill(x, y-1, fill_color, bounday_color);

        boundary_fill(x-1, y-1, fill_color, bounday_color);
        boundary_fill(x-1, y+1, fill_color, bounday_color);
        boundary_fill(x-1, y+1, fill_color, bounday_color);
        boundary_fill(x+1, y-1, fill_color, bounday_color);
    }

}

